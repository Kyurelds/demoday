<?php

if(!empty($_POST['nome_login']) && !empty($_POST['senha_login'])){
 
    $usuario=$_POST['nome_login'];
    $senha=$_POST['senha_login'];
}
else{
    echo("<script>alert('usuario ou senha incorretos');window.location.href='login.html#paralogin';</script>");
}
$sql="SELECT * FROM register WHERE gmail='$usuario' AND senha='$senha'";


include('conexao.php');

$resultado=mysqli_query($conn,$sql);

$linha=mysqli_fetch_array($resultado);


if(!$linha)  
    {
        echo ("<script> 
            alert('usuario ou senha incorretos !');
            window.location.href='login.html#paralogin';
        </script>");
    }
    else 
    {
        session_start();
        $_SESSION['nomecompleto']=$linha['nomecompleto'];

        echo ("<script>
            window.location.href='index.html';
        </script>");
    }