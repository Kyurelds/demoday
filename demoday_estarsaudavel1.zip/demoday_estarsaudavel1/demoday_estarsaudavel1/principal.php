<?php
session_start();
echo('usuario: '.$_SESSION['megume']);

//destruindo a sessãp
session_unset();
session_destroy();

?>
