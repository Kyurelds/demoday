# tela-login
Tela de login com cadastro em PHP e MySQL.

O projeto contem:
-Tela de login e tela de cadastro com Interface em HTML5
-Classe usuarios.php no diretorio classes com as funções conectar, cadastrar e logar
-Arquivo sair.php para logoff
-Aquivo valida.php com as funcionalidades de validação dos dados do cadastro
-Arquivo do banco de dados com uma tabela chamada usuarios

Como usar:
1.Instale o XAMPP, LAMPP ou outro pacote com Apache+PHP+MySQL.
2.Copie a pasta tela-login para o seu diretório www.
3.Crie um banco de dados com o nome tela-login e importe o arquivo sql com a tabela.
4.Acesse a aplicação através do navegador.

