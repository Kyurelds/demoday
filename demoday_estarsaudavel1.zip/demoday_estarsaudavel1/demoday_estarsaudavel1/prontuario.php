<?php
$nome=$_POST['nome'];
$sexo=$_POST['sexo'];
$profissao=$_POST['profissao'];
$endereco=$_POST['endereco'];
$telefone=$_POST['telefone'];
$peso=$_POST['peso'];
$altura=$_POST['altura'];
$tiposanguineo=$_POST['tiposanguineo'];
$medicamento=$_POST['medicamento'];
$alcool=$_POST['alcool'];
$consulta=$_POST['consulta'];
$cronicas=$_POST['cronicas'];
$diagnostico=$_POST['diagnostico'];
$tratamento=$_POST['tratamento'];
$cirurgia=$_POST['cirurgia'];
$Internacao=$_POST['Internacao'];
$alergias=$_POST['alergias'];
$idade=$_POST['idade'];

include('conexao.php');

$sql="INSERT INTO prontuario(nome,sexo,profissao,endereco,telefone,peso,altura,tipo_sanguineo,usa_meticamento,alcool_fuma,deseja_consulta,doencas_cronicas,diagnostico,tratamento,cirurgia,internacao,alergia,idade)
VALUE('$nome','$sexo','$profissao','$endereco','$telefone','$peso','$altura','$tiposanguineo','$medicamento','$alcool','$consulta','$cronicas','$diagnostico','$tratamento','$cirurgia','$Internacao','$alergias','$idade')";


$resultado=mysqli_query($conn, $sql) or die('Falha no prontuário');

mysqli_close($conn);

echo("<script>alert('prontoario salvo com susseso ');
window.location.href='index.html';</script>");
?>