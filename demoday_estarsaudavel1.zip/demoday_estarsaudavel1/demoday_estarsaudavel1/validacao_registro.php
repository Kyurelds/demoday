<?php
$nome=$_POST['nome_cad'];
$gmail=$_POST['email_cad'];
$senha=$_POST['senha_cad'];
$cpf=$_POST['cpf'];
$rg=$_POST['rg_cad'];
$telefone=$_POST['telefone_cad'];
$celular=$_POST['celular_cad'];
$rua=$_POST['rua_cad'];
$bairro=$_POST['bairro_cad'];
$numero=$_POST['numero_cad'];
$cep=$_POST['cep_cad'];
$cidade=$_POST['cidade_cad'];
$estado=$_POST['estado_cad'];
$data_nasc=$_POST['nasc'];

include('conexao.php');

$sql="INSERT INTO register(nome,gmail,senha,cpf,rg,telefone,celular,rua,bairro,numero,cep,cidade,estado,data_nasc)
VALUE ('$nome','$gmail','$senha','$cpf','$rg','$telefone','$celular','$rua','$bairro','$numero','$cep','$cidade','$estado','$data_nasc')";

$resultado=mysqli_query($conn,$sql) or die('falha no registro!');

mysqli_close($conn);

echo("<script>alert('catastrado com susseso ');
window.location.href='login.html#paralogin';</script>");
?>